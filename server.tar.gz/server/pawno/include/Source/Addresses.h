/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#ifdef WIN32
	#define LOGPRINTF_0303						((logprintf_t)0x00477470)
	#define LOGPRINTF_0304						((logprintf_t)0x004775A0)
	#define NETGAME_0303						((void *)0x004BB07C)
	#define NETGAME_0304						((void *)0x004BB07C)
	#define CONSOLE_0303						((void **)0x004BB080)
	#define CONSOLE_0304						((void **)0x004BB080)
	
	#define CONSOLE_ADD_RULE_0303				((void *)0x00477180)
	#define CONSOLE_ADD_RULE_0304				((void *)0x004772B0)
	#define CONSOLE_SET_RULE_0303				((void *)0x00476160)
	#define CONSOLE_SET_RULE_0304				((void *)0x00476290)
	
	#define CSTREAM__CONS_0303					((void *)0x00448190)
	#define CSTREAM__CONS_0304					((void *)0x00448190)
	#define CSTREAM__DEST_0303					((void *)0x004482A0)
	#define CSTREAM__DEST_0304					((void *)0x004482A0)
	#define CSTREAM__WRITE_0303					((void *)0x004487F0)
	#define CSTREAM__WRITE_0304					((void *)0x004487F0)
	#define CSTREAM__SEND_0303					((void *)0x00454EA0)
	#define CSTREAM__SEND_0304					((void *)0x00454EA0)
	#define CSTREAM__GET_ID_0303				((void *)0x004550E0)
	#define CSTREAM__GET_ID_0304				((void *)0x004550E0)
	
	#define G_F_RESTART_WAIT_TIME_0303			((float *)0x0049CC04)
	#define G_F_RESTART_WAIT_TIME_0304			((float *)0x0049CC04)
	
	#define INVALID_NICK_0_0303					((DWORD)0x00466F99)
	#define INVALID_NICK_0_0304					((DWORD)0x00466FB9)
	#define INVALID_NICK_1_0303					((DWORD)0x0047B90B)
	#define INVALID_NICK_1_0304					((DWORD)0x0047BADB)
	#define INVALID_NICK_2_0303					((DWORD)0x0047BC9D)
	#define INVALID_NICK_2_0304					((DWORD)0x0047BE6D)
#else
	#define LOGPRINTF_0303						((logprintf_t)0x08074EFC)
	#define LOGPRINTF_0304						((logprintf_t)0x08074F58)
	#define NETGAME_0303						((void *)0x0813AEF4)
	#define NETGAME_0304						((void *)0x0813AEF4)
	#define CONSOLE_0303						((void **)0x0813AEF8)
	#define CONSOLE_0304						((void **)0x0813AEF8)
	
	#define CONSOLE_ADD_RULE_0303				((void *)0x0805C5B4)
	#define CONSOLE_ADD_RULE_0304				((void *)0x0805C5C8)
	#define CONSOLE_SET_RULE_0303				((void *)0x0805C88A)
	#define CONSOLE_SET_RULE_0304				((void *)0x0805C89E)
	
	#define CSTREAM__CONS_0303					((void *)0x080551CE)
	#define CSTREAM__CONS_0304					((void *)0x080551E2)
	#define CSTREAM__DEST_0303					((void *)0x08055504)
	#define CSTREAM__DEST_0304					((void *)0x08055518)
	#define CSTREAM__WRITE_0303					((void *)0x08055920)
	#define CSTREAM__WRITE_0304					((void *)0x08055934)
	#define CSTREAM__SEND_0303					((void *)0x080786FC)
	#define CSTREAM__SEND_0304					((void *)0x0807877C)
	#define CSTREAM__GET_ID_0303				((void *)0x0809D1F4)
	#define CSTREAM__GET_ID_0304				((void *)0x0809D3B4)
	
	#define G_F_RESTART_WAIT_TIME_0303			((float *)0x08111AFC)
	#define G_F_RESTART_WAIT_TIME_0304			((float *)0x08111F9C)
	
	#define INVALID_NICK_0_0303					((DWORD)0x0807AF6E)
	#define INVALID_NICK_0_0304					((DWORD)0x0807B04A)
	#define INVALID_NICK_1_0303					((DWORD)0x0807B619)
	#define INVALID_NICK_1_0304					((DWORD)0x0807B6F5)
	#define INVALID_NICK_2_0303					((DWORD)0x080AFDAF)
	#define INVALID_NICK_2_0304					((DWORD)0x080AFF97)
	
	#define STRLWR_FIX_0303						((DWORD)0x08074466)
	#define STRLWR_FIX_0304						((DWORD)0x080744C2)
#endif
