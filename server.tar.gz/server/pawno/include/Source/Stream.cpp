/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 *  Incognito for repeatedly testing this file on Linux.
 */

#include "Stream.h"
#include "Server.h"

extern FakeMethod_void
	g_pCStream__cons,
	g_pCStream__dest;

extern CStream__Send_t
	g_pCStream__Send;

extern CStream__GetID_t
	g_pGetPlayerID;

extern logprintf_t
	logprintf;

extern CServer *
	g_pServer;

#define _SERVER ((FakeClass *)(g_pServer->GetServer()))
#define _RAKNET ((FakeClass *)(g_pServer->GetFirst()))
#define _STREAM ((FakeClass *)_DATA)
#define _DATA   (&this->m_csPad)

#ifdef WIN32
	#define METHOD_CALL(m,n,o) \
		(m->*n)(o)
	#define METHOD_VOID(m,n) \
		(m->*n)()
#else
	#define METHOD_CALL(m,n,o) \
		n(m, o)
	#define METHOD_VOID(m,n) \
		n(m)
#endif

// cons
	CStream::
	CStream()
{
	METHOD_VOID(_STREAM, g_pCStream__cons);
}

// dest
	CStream::
	~CStream()
{
	METHOD_VOID(_STREAM, g_pCStream__dest);
}

void
	CStream::
	Send(char * type, PLAYERID playerid)
{
	bool
		broadcast = (playerid == INVALID_PLAYER_ID);
	#ifdef WIN32
		(_RAKNET->*g_pCStream__Send)(type, _DATA, 1, 2, 0, GetPlayer(playerid), broadcast, false);
	#else
		g_pCStream__Send(_SERVER, type, _DATA, 1, 2, 0, GetPlayer(playerid), broadcast, false);
	#endif
}

SS_PlayerID
	INVALID_PLAYERID = { 0xFFFFFFFF, 0xFFFF };

SS_PlayerID
	CStream::
	GetPlayer(PLAYERID playerid)
{
	return METHOD_CALL(_RAKNET, g_pGetPlayerID, playerid);
}
