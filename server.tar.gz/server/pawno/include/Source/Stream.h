/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#pragma once
#include "Structs.h"

#ifdef WIN32
	typedef void (FakeClass::* CStream__Send_t)(char *, SS_CStream *, int, int, char, SS_PlayerID, bool, bool);
	typedef void (FakeClass::* CStream__Write_t)(void *, int, bool);
	typedef SS_PlayerID (FakeClass::* CStream__GetID_t)(int);
#else
	typedef void (* CStream__Send_t)(FakeClass *, char *, SS_CStream *, int, int, char, SS_PlayerID, bool, bool);
	typedef void (* CStream__Write_t)(FakeClass *, void *, int, bool);
	typedef SS_PlayerID (* CStream__GetID_t)(FakeClass *, int);
#endif

extern CStream__Write_t
	g_pCStream__Write;

class CStream
{
public:
	// cons
		CStream();
	
	// dest
		~CStream();
	
	template <class T>
	inline void
		Write(T data)
	{
		#ifdef WIN32
			((FakeClass *)(&this->m_csPad)->*g_pCStream__Write)((void *)&data, sizeof (T) * 8, true);
		#else
			g_pCStream__Write((FakeClass *)(&this->m_csPad), (void *)&data, sizeof (T) * 8, true);
		#endif
	};
	
	void
		Send(char *type, PLAYERID playerid);
	
	void
		Reset()
	{
		m_csPad.pad0 = 0;
		m_csPad.pad2 = 0;
	};
	
private:
	SS_CStream
		m_csPad;
	
	SS_PlayerID
		GetPlayer(PLAYERID playerid);
};
