/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#pragma once

#include "../main.h"

#pragma pack(push)

#pragma pack(1)
typedef struct
	SS_CPlayerPool
{
	BOOL
		bPlayerConnected[MAX_PLAYERS];
}
SS_CPlayerPool;

#pragma pack(1)
typedef struct
	SS_CServer
{
	void *
		pFirst;
	SS_CPlayerPool *
		pPlayerPool;
	char
		pad0[12];
	void *
		pGameMode;
}
SS_CServer;

#pragma pack(1)
typedef struct
	SS_CStream
{
	int
		pad0,
		pad1,
		pad2;
	char
		pad3[261];
}
SS_CStream;

#pragma pack(1)
typedef struct
	SS_PlayerID
{
	unsigned long
		pad0;
	unsigned short
		pad1;
}
SS_PlayerID;

#pragma pack(pop)
