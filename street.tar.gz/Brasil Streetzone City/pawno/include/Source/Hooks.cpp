/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#ifdef WIN32
	#define WIN32_LEAN_AND_MEAN
	#define VC_EXTRALEAN
	#include <Windows.h>
#else
	#include <stdio.h>
	#include <sys/mman.h>
	#include <limits.h>
	#include <string.h>
#endif

#include "../main.h"
#include "Addresses.h"
#include "Inlines.h"

#include "Stream.h"

#ifndef PAGESIZE
	#define PAGESIZE (4096)
#endif

extern int
	g_iServerVersion;

extern logprintf_t
	logprintf;

FakeMethod_void
	g_pCStream__cons = 0,
	g_pCStream__dest = 0;

CStream__Send_t
	g_pCStream__Send = 0;

CStream__Write_t
	g_pCStream__Write = 0;

void
	*g_pConsole = 0;

CStream__GetID_t
	g_pGetPlayerID = 0;

float
	*g_fpRestartWaitTime;

AddServerRule_t
	g_pCConsole__AddRule = 0;

SetServerRule_t
	g_pCConsole__SetRule = 0;

bool
	Unlock(void *address, int len)
{
	#ifdef WIN32
		DWORD
			oldp;
		// Shut up the warnings :D
		return !!VirtualProtect(address, len, PAGE_EXECUTE_READWRITE, &oldp);
	#else
		return !mprotect((LPVOID)(((int)address / PAGESIZE) * PAGESIZE), PAGESIZE, PROT_WRITE | PROT_READ | PROT_EXEC);
	#endif
}

void
	Call(DWORD from, DWORD to)
{
	if (Unlock((LPVOID)from, 5))
	{
		DWORD
			disp = to - (from + 5);
		*(BYTE *)(from) = 0xE8;
		*(DWORD *)(from + 1) = (DWORD)disp;
	}
}

void
	WriteBytes(DWORD address, BYTE *data, DWORD size)
{
	if (Unlock((LPVOID)address, size))
	{
		memcpy((void *)address, data, size);
	}
}

void
	NOPRange(DWORD start, DWORD length)
{
	if (Unlock((LPVOID)start, length))
	{
		memset((LPVOID)start, 0x90, length);
	}
}

void
	Jump(DWORD from, DWORD to)
{
	if (Unlock((LPVOID)from, 5))
	{
		if ((int)to < (int)from || ((int)to - (int)from) >= 0x82)
		{
			// 0x82 to account for OpCode length
			// long
			*(BYTE *)(from) = 0xE9;
			*(DWORD *)(from + 1) = (DWORD)((int)to - ((int)from + 5));
		}
		else
		{
			// short
			*(BYTE *)(from) = 0xEB;
			*(BYTE *)(from + 1) = (BYTE)(to - (from + 2));
		}
	}
}

// Hopefully this will be optimised out
// Unfortunately I can't get ANY direct cast to work
// pointer_to_member seems like a very special structure
// Edit: Seems like it is optimised out, good, so this
// just bypasses the compilers checks to do what I want
#define POINTER_TO_MEMBER(m,n,o) temp = n, m = *(o *)&temp

void
	GetAddresses()
{
	void
		*temp;
	switch (g_iServerVersion)
	{
		case SERVER_VERSION_0303:
			// Streams for SetPlayerGravity.
			POINTER_TO_MEMBER(g_pCStream__cons, CSTREAM__CONS_0303, FakeMethod_void);
			POINTER_TO_MEMBER(g_pCStream__dest, CSTREAM__DEST_0303, FakeMethod_void);
			POINTER_TO_MEMBER(g_pCStream__Write, CSTREAM__WRITE_0303, CStream__Write_t);
			POINTER_TO_MEMBER(g_pGetPlayerID, CSTREAM__GET_ID_0303, CStream__GetID_t);
			POINTER_TO_MEMBER(g_pCStream__Send, CSTREAM__SEND_0303, CStream__Send_t);
			// Restart time pointer.
			g_fpRestartWaitTime = G_F_RESTART_WAIT_TIME_0303;
			// Console for adding rules.
			g_pConsole = *CONSOLE_0303;
			POINTER_TO_MEMBER(g_pCConsole__AddRule, CONSOLE_ADD_RULE_0303, AddServerRule_t);
			POINTER_TO_MEMBER(g_pCConsole__SetRule, CONSOLE_SET_RULE_0303, SetServerRule_t);
			break;
		case SERVER_VERSION_0304:
			// Streams for SetPlayerGravity.
			POINTER_TO_MEMBER(g_pCStream__cons, CSTREAM__CONS_0304, FakeMethod_void);
			POINTER_TO_MEMBER(g_pCStream__dest, CSTREAM__DEST_0304, FakeMethod_void);
			POINTER_TO_MEMBER(g_pCStream__Write, CSTREAM__WRITE_0304, CStream__Write_t);
			POINTER_TO_MEMBER(g_pGetPlayerID, CSTREAM__GET_ID_0304, CStream__GetID_t);
			POINTER_TO_MEMBER(g_pCStream__Send, CSTREAM__SEND_0304, CStream__Send_t);
			// Restart time pointer.
			g_fpRestartWaitTime = G_F_RESTART_WAIT_TIME_0304;
			// Console for adding rules.
			g_pConsole = *CONSOLE_0304;
			POINTER_TO_MEMBER(g_pCConsole__AddRule, CONSOLE_ADD_RULE_0304, AddServerRule_t);
			POINTER_TO_MEMBER(g_pCConsole__SetRule, CONSOLE_SET_RULE_0304, SetServerRule_t);
			break;
	}
	Unlock(g_fpRestartWaitTime, 4);
}

void
	InstallPreHooks()
{
	GetAddresses();
	// Main loop
	#ifndef WIN32
		// I can't even remember what this did...
		BYTE
			lwrFix[1] = {0x04};
		switch (g_iServerVersion)
		{
			case SERVER_VERSION_0303:
				// Fix strlwr
				WriteBytes(STRLWR_FIX_0303, lwrFix, 1);
				break;
			case SERVER_VERSION_0304:
				// Fix strlwr
				WriteBytes(STRLWR_FIX_0304, lwrFix, 1);
				break;
		}
	#endif
}

void
	InstallPostHooks()
{
	// For things which need setting up after pNetGame is initiated
}
