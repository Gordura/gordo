/*  
 *  Version: MPL 1.1
 *  
 *  The contents of this file are subject to the Mozilla Public License Version 
 *  1.1 (the "License"); you may not use this file except in compliance with 
 *  the License. You may obtain a copy of the License at 
 *  http://www.mozilla.org/MPL/
 *  
 *  Software distributed under the License is distributed on an "AS IS" basis,
 *  WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 *  for the specific language governing rights and limitations under the
 *  License.
 *  
 *  The Original Code is the YSI 2.0 SA:MP plugin.
 *  
 *  The Initial Developer of the Original Code is Alex "Y_Less" Cole.
 *  Portions created by the Initial Developer are Copyright (C) 2008
 *  the Initial Developer. All Rights Reserved.
 *  
 *  Contributor(s):
 *  
 *  Peter Beverloo
 *  Marcus Bauer
 *  MaVe;
 *  Sammy91
 *  Incognito
 *  
 *  Special Thanks to:
 *  
 *  SA:MP Team past, present and future
 */

#include <malloc.h>
#include <string.h>

#include "../main.h"

#include "Inlines.h"
#include "Stream.h"

extern float
	*g_fpRestartWaitTime;

extern void
	*g_pConsole;

extern AddServerRule_t
	g_pCConsole__AddRule;

extern SetServerRule_t
	g_pCConsole__SetRule;

extern int
	g_iServerVersion;

#define _CONSOLE ((FakeClass *)g_pConsole)

void
	SetModeRestartTime(float time)
{
	*g_fpRestartWaitTime = time;
}

void
	AddServerRule(char * rule, char * value)
{
	// This call (and the others like it) will give a debug assertaion error however the call is safe
	#ifdef WIN32
		(_CONSOLE->*g_pCConsole__AddRule)(rule, 4, value, 0);
	#else
		g_pCConsole__AddRule(_CONSOLE, rule, 4, value, 0);
	#endif
}

void
	SetServerRule(char * rule, char * value)
{
	#ifdef WIN32
		(_CONSOLE->*g_pCConsole__SetRule)(rule, value);
	#else
		// Linux messes up lowercase
		// But not any more :D
		g_pCConsole__SetRule(_CONSOLE, rule, value);
	#endif
}
